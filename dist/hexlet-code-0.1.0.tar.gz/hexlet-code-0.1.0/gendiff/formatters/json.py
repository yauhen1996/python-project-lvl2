import json


def json_(arg):
    return json.dumps(arg, indent=2)
